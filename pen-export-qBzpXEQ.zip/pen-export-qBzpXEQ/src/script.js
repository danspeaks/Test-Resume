// Function to handle showing and hiding sections
function showSection(targetId) {
    // Hide all sections
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => {
        section.style.display = 'none';
    });

    // Show the target section
    const targetSection = document.getElementById(targetId);
    if (targetSection) {
        targetSection.style.display = 'block';
    }
}

// Attach event listeners to navigation links
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = e.target.getAttribute('data-target');
        showSection(targetId);
    });
});

// Initially show the resume section (or any default section)
document.addEventListener('DOMContentLoaded', () => {
    showSection('resume-section'); // Default section
});
